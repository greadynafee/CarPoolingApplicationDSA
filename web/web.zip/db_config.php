<?php
 
 //All connection data variables
 
 define('DB_USER',"root");
 define('DB_PASSWORD',"");
 define('DB_DATABASE',"carpooling");
 DEFINE('DB_SERVER',"localhost");
 ?>
 
 